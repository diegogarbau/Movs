package com.sopra.onBoarding.DTO;

import com.sopra.onBoarding.entities.Mov;

import java.util.List;

public class ActorDTO {
    private String name;
    private List<MovShortDTO> filmography;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<MovShortDTO> getFilmography() {
        return filmography;
    }

    public void setFilmography(List<MovShortDTO> filmography) {
        this.filmography = filmography;
    }

    public static class Builder {
        private String name;
        private List<MovShortDTO> filmography;

        public Builder setName(String name) {
            this.name = name;
            return this;

        }

        public Builder setFilmography(List<MovShortDTO> filmography) {
            this.filmography = filmography;
            return this;
        }

        public ActorDTO build() {
            ActorDTO actor = new ActorDTO();
            actor.setName(name);
            actor.setFilmography(filmography);
            return actor;
        }
    }
}
