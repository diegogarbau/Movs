package com.sopra.onBoarding.services.imp;

import com.sopra.onBoarding.DTO.MovDetailDTO;
import com.sopra.onBoarding.DTO.MovInputDTO;
import com.sopra.onBoarding.DTO.MovsDTO;
import com.sopra.onBoarding.DTO.mapper.MovCompiler;
import com.sopra.onBoarding.DTO.mapper.MovToDTO;
import com.sopra.onBoarding.entities.Mov;
import com.sopra.onBoarding.exceptions.notFoundExceptions.NotFoundException;
import com.sopra.onBoarding.exceptions.wrongInputExceptions.DuplicatedException;
import com.sopra.onBoarding.exceptions.wrongInputExceptions.WrongInputLongException;
import com.sopra.onBoarding.persistance.MovDAO;
import com.sopra.onBoarding.services.MovService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MovServiceImpl implements MovService {
    private MovDAO movDao;

    @Autowired
    public MovServiceImpl(MovDAO movDao) {
        this.movDao = movDao;
    }

    @Override
    public MovsDTO getAllMovies() {
        List<Mov> listFilm = movDao.findAll();
        MovsDTO moviesResult = new MovsDTO();
        if (!listFilm.isEmpty()) {
            moviesResult.insertAll(listFilm.stream()
                                            .map(movEntt -> MovToDTO.mapperShort(movEntt))
                                            .collect(Collectors.toList()));
        }
        return moviesResult;
    }

    @Override
    public MovDetailDTO getMovie(String title) {
       return MovToDTO.mapperLong(movDao.findByTitle(title).orElseThrow(() -> new NotFoundException(
               String.format("La pelicula '%s' del año %d no figura en la base de datos", title))));

    }

    @Override
    public MovDetailDTO createMov(MovInputDTO movInputDTO) {
        return null;
    }

    public void ThrowIfInvalidMovie(MovInputDTO peliculaDTO) {
        String validated = MovCompiler.checkMovieDto(peliculaDTO);
        if (!validated.equals("Valida")) {
            throw new WrongInputLongException(
                    String.format("La pelicula no se ha procesado por el siguiente motivo: %s", validated));
        }
    }

    public void throwIfDuplicatedMovie(MovInputDTO movInputDTO) {
        Optional<Mov> peliPosible = movDao.findByTitle(movInputDTO.getTitle(), movInputDTO.getYear());
        if (peliPosible.isPresent() && checker.compareMovieToDto(peliPosible.get(), movInputDTO)) {
            throw new DuplicatedException(
                    String.format("La pelicula '%s' del año %d no se ha insertado porque ya existe en la base de datos",
                            movInputDTO.getTitle(), movInputDTO.getYear()));
        }
    }

    @Override
    public MovDetailDTO modifyMov(Long idMov, MovInputDTO movInputDTO) {
        return null;
    }

    @Override
    public void deleteMov(String title) {

    }

    @Override
    public void deleteMov(Long idMov) {

    }
}
