package com.sopra.onBoarding.exceptions.wrongInputExceptions;

public abstract class WrongInputShortException extends BadRequestMotherException {

    private static final long serialVersionUID = 1L;

    public WrongInputShortException(String mensaje) {
        super(mensaje);
        // TODO Auto-generated constructor stub
    }
}