package com.sopra.onBoarding.services;

import com.sopra.onBoarding.DTO.MovDetailDTO;
import com.sopra.onBoarding.DTO.MovInputDTO;
import com.sopra.onBoarding.DTO.MovsDTO;

public interface MovService {
    MovsDTO getAllMovies();
    MovDetailDTO getMovie(String title);
    MovDetailDTO createMov(MovInputDTO movInputDTO);
    MovDetailDTO modifyMov(Long idMov, MovInputDTO movInputDTO);
    void deleteMov(String title);
    void deleteMov(Long idMov);
}
