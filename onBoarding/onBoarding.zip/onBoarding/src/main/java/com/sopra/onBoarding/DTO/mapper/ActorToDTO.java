package com.sopra.onBoarding.DTO.mapper;

import com.sopra.onBoarding.DTO.ActorDTO;
import com.sopra.onBoarding.DTO.MovShortDTO;
import com.sopra.onBoarding.entities.Actor;

import java.util.stream.Collectors;

public class ActorToDTO {
    public static ActorDTO mapper(Actor actor) {
        return new ActorDTO.Builder()
                .setName(actor.getName())
                .setFilmography(actor.getFilmography()
                        .stream()
                        .map(MovToDTO::mapperShort)
                        .collect(Collectors.toList())
                )
                .build();
    }
}

