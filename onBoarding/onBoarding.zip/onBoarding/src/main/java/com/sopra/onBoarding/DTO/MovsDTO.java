package com.sopra.onBoarding.DTO;

import java.util.List;

public class MovsDTO {
    private List<MovShortDTO> movs;

    public List<MovShortDTO> getMovs() {
        return movs;
    }

    public void setMovs(List<MovShortDTO> movs) {
        this.movs = movs;
    }

    public MovsDTO insertAll(List<MovShortDTO> listaPeliculasDTO) {
        movs.addAll(listaPeliculasDTO);
        return this;
    }
}
