package com.sopra.onBoarding.entities;

import java.util.List;

public class Actor {
    private Long idMov;
    private String name;
    private List<Mov> filmography;

    public Long getIdMov() {
        return idMov;
    }

    public void setIdMov(Long idMov) {
        this.idMov = idMov;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Mov> getFilmography() {
        return filmography;
    }

    public void setFilmography(List<Mov> filmography) {
        this.filmography = filmography;
    }

    public static class Builder {
        private Long idMov;
        private String name;
        private List<Mov> filmography;

        public Builder setIdMov(Long idMov) {
            this.idMov = idMov;
            return this;
        }

        public Builder setName(String name) {
            this.name = name;
            return this;

        }

        public Builder setFilmography(List<Mov> filmography) {
            this.filmography = filmography;
            return this;
        }

        public Actor build() {
            Actor actor = new Actor();
            actor.setIdMov(idMov);
            actor.setName(name);
            actor.setFilmography(filmography);
            return actor;
        }
    }
}
