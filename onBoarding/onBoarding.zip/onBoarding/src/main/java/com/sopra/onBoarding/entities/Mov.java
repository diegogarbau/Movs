package com.sopra.onBoarding.entities;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "movs")
public class Mov {
    private Long idMov;
    private String title;
    private String genre;
    private int year;
    private List<Actor> cast;

    public Long getIdMov() {
        return idMov;
    }

    public void setIdMov(Long idMov) {
        this.idMov = idMov;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public List<Actor> getCast() {
        return cast;
    }

    public void setCast(List<Actor> cast) {
        this.cast = cast;
    }

    public class Builder{
        private Long idMov;
        private String title;
        private String genre;
        private int year;
        private List<Actor> cast;

        public Builder setIdMov(Long idMov) {
            this.idMov = idMov;
            return this;
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder setGenre(String genre) {
            this.genre = genre;
            return this;
        }

        public Builder setYear(int year) {
            this.year = year;
            return this;
        }

        public Builder setCast(List<Actor> cast) {
            this.cast = cast;
            return this;
        }
        public Mov build(){
            Mov mov = new Mov();
            mov.setIdMov(idMov);
            mov.setTitle(title);
            mov.setGenre(genre);
            mov.setYear(year);
            mov.setCast(cast);
            return mov;
        }
    }
}
