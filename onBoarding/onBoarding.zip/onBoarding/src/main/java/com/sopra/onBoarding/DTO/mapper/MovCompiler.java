package com.sopra.onBoarding.DTO.mapper;

import com.sopra.onBoarding.DTO.ActorDTO;
import com.sopra.onBoarding.DTO.MovDetailDTO;
import com.sopra.onBoarding.DTO.MovShortDTO;
import com.sopra.onBoarding.entities.Mov;

public class MovCompiler {
    public static String checkMovieDto(MovDetailDTO movDTO) {
        if (movDTO == null) {
            return "Pelicula Null";
        }
        if (movDTO.getTitle() == null || "" == movDTO.getTitle()) {
            return "Error en el titulo";
        }
        if (movDTO.getGenre() == null || "" == movDTO.getGenre()) {
            return "Error en el genero";
        }
        if (movDTO.getYear() > 2020 || movDTO.getYear() <= 1885) {
            return "Error en el año";
        }

        if (movDTO.getCast() == null || movDTO.getCast().isEmpty()) {
            return "Error en la lista de actores";
        }
        for (ActorDTO a : movDTO.getCast()) {
            if (a == null) {
                return "Error en un actor";
            }
            if (a.getName() == null || "" == a.getName()) {
                return "Error en el nombre de un actor";
            }
        }
        return "Valida";
    }

    public static String checkMovieShortDto(MovShortDTO movDTO) {
        if (movDTO == null) {
            return "Pelicula Null";
        }
        if (movDTO.getTitle() == null || "" == movDTO.getTitle()) {
            return "Error en el titulo";
        }
        if (movDTO.getYear() > 2020 || movDTO.getYear() <= 1885) {
            return "Error en el año";
        }
        return "Valida";
    }

    public static boolean compareMovieToDto(Mov mov, MovShortDTO movDto) {
        boolean identical = true;
        if (!mov.getTitle().equals(movDto.getTitle())) {
            identical = false;
        }
        if (mov.getYear() != movDto.getYear()) {
            identical = false;
        }
        return identical;
    }
}
