package com.sopra.onBoarding.exceptions;

public abstract class GreatMotherException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public GreatMotherException(String mensaje) {
        super(mensaje);
        // TODO Auto-generated constructor stub
    }
}