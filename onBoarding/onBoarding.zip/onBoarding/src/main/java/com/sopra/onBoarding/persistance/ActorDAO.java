package com.sopra.onBoarding.persistance;

import com.sopra.onBoarding.entities.Actor;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface ActorDAO extends CrudRepository<Actor, Integer> {

    Optional<Actor> findByName (String name);
}
