package com.sopra.onBoarding.exceptions.wrongInputExceptions;

public abstract class WrongInputLongException extends BadRequestMotherException {

    private static final long serialVersionUID = 1L;

    public WrongInputLongException(String mensaje) {
        super(mensaje);
        // TODO Auto-generated constructor stub
    }
}