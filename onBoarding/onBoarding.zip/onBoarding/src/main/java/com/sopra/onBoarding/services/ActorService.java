package com.sopra.onBoarding.services;

public class ActorService {
}
